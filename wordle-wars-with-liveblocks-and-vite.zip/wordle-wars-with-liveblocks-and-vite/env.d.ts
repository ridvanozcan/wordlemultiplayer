/// <reference types="vue/macros-global" />
