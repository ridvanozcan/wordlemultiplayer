import { InjectionKey } from 'vue'

export const clientSymbol = Symbol() as InjectionKey<string>
export const roomSymbol = Symbol() as InjectionKey<string>
