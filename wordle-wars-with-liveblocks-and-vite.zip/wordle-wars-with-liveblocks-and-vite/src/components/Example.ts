export const info = {
  hide: false,
  title: 'Wordle wars',
  description: 'Share the link to play this Wordle clone live with others. Open it in a new window to try it against yourself.',
  githubHref: 'https://github.com/CTNicholas/wordle-wars',
  codeSandboxHref: '',
  twitterHref: 'https://twitter.com/@ctnicholasdev',
  website: 'https://ctnicholas.dev'
}
